"""高保真热解：enthalpy 法（焓法）相变热传导
=============================================

本模块把「连续介质热解带潜热/固液-液固相变」落地为 ForgeCore 可注册求解器
``thermal.enthalpy``，替换/补充代理级 ``thermal.history``，是 P2-①「真实模拟」
最前置的硬缺口。

物理方法
--------
采用 **enthalpy（焓）法**（Voller & Prakash 经典算法），把潜热吸收/释放嵌入
热传导方程，无需显式追踪固液界面：

    状态量 H(x,t) ：单位体积焓 [J/m³]
    ∂H/∂t = ∇·(k ∇T) + Q(x,t)            # Q 为移动高斯激光热源

其中温度与焓通过**平滑**的液相关系 f(T) 关联（避免可微性破缺）：

    H(T) = ρ c_p (T − T_amb) + ρ L f(T)
    f(T) = smoothstep(T; T_solidus, T_liquidus)   # 0=固, 1=液
    dH/dT = ρ c_p + ρ L f'(T)  ≥  ρ c_p  > 0       # 单调 → 可逆

于是 ∇T = (dT/dH) ∇H，扩散项改写为

    ∇·(k ∇T) = ∇·( α_H ∇H ),  α_H = k / (ρ c_p + ρ L f'(T))

在固/液区 f'=0 → α_H = k/(ρ c_p)（纯扩散）；在糊状区(mushy) f'>0 →
α_H 被压低，能量转入相变、温度平台出现——这正是潜热效应的数值体现，且整条
公式对 H、对工艺参数（扫描速度、功率等 tracer）**全程可微**。

输出 ThermalHistory 字段的物理来源
----------------------------------
* peak_temperature   : 逐体素峰值温度（扫描中跟踪）
* final_temperature  : 末态温度场
* cooling_rate       : 逐体素最大冷却速率（跟踪 dT/dt）
* thermal_gradient   : 末态温度梯度 |∇T|（凝固前沿 G）
* solidification_rate: R = 冷却速率 / max(G, ε)（凝固前沿推进速率）
* time_above_melt    : T > T_solidus 累计时间（重熔代理）

设计要点
--------
* 纯 JAX 实现，兼容 ``jax.jit`` / ``jax.grad`` / ``jax.lax.scan``。
* 液相关联 f 用 smoothstep，逆映射 T(H) 用固定步数 Newton（8 步，可微）。
* 边界：Neumann（绝热）；可选弱 Newton 冷却项防止数值过热。
* 与 9 契约链一致：consumes (geometry, process)，produces ThermalHistory。
"""

from __future__ import annotations

import math

import jax
import jax.numpy as jnp

from amforge.core.contracts import PartGeometry, ProcessPlan, ThermalHistory
from amforge.core.registry import register_solver
from amforge.materials import get_material


# ---------------------------------------------------------------------------
# 相变（液相关联 f 与逆映射）—— 平滑、可微
# ---------------------------------------------------------------------------
def liquid_fraction(T, T_sol, T_liq):
    """平滑液相关系 f(T) ∈ [0,1]（smoothstep 跨糊状区）。"""
    dT = max(T_liq - T_sol, 1.0)
    s = jnp.clip((T - T_sol) / dT, 0.0, 1.0)
    return s * s * (3.0 - 2.0 * s)


def d_liquid_fraction(T, T_sol, T_liq):
    """df/dT ≥ 0（smoothstep 导数，糊状区为凸包、边界处归零）。"""
    dT = max(T_liq - T_sol, 1.0)
    s = jnp.clip((T - T_sol) / dT, 0.0, 1.0)
    return 6.0 * s * (1.0 - s) / dT


def temperature_of_enthalpy(H, *, rho, cp, L, T_amb, T_sol, T_liq, n_iter=24):
    """T(H)：由单调焓-温关系反解（二分法，可微、稳定）。

    H(T) = ρ c_p (T−T_amb) + ρ L f(T) 对 T 严格单调增，故用二分法在
    [T_amb, T_amb+(H+ρL)/(ρc_p)] 内求根，不依赖导数、不会跨平段振荡，
    固定步数即可达机器精度，且全程对 H 可微。
    """
    a = rho * cp
    b = rho * L
    T_lo = jnp.full_like(H, T_amb)
    T_hi = T_amb + (H + b) / jnp.maximum(a, 1e-12)

    def body(carry, _):
        lo, hi = carry
        mid = 0.5 * (lo + hi)
        Hmid = a * (mid - T_amb) + b * liquid_fraction(mid, T_sol, T_liq)
        lo = jnp.where(Hmid < H, mid, lo)
        hi = jnp.where(Hmid < H, hi, mid)
        return (lo, hi), None

    (lo, hi), _ = jax.lax.scan(body, (T_lo, T_hi), jnp.arange(n_iter))
    return 0.5 * (lo + hi)


def effective_diffusivity(T, *, k, rho, cp, L, T_sol, T_liq):
    """糊状区被压低的有效扩散系数 α_H = k / (ρ c_p + ρ L f'(T))。"""
    denom = rho * cp + rho * L * d_liquid_fraction(T, T_sol, T_liq)
    return k / jnp.maximum(denom, 1e-12)


# ---------------------------------------------------------------------------
# 变系数扩散 ∇·(α ∇H) —— 3D/2D 通用，Neumann 边界
# ---------------------------------------------------------------------------
def _div_alpha_grad(H, alpha, dx):
    div = jnp.zeros_like(H)
    ndim = H.ndim
    for ax in range(ndim):
        idx = jnp.arange(H.shape[ax])
        Hc = jnp.take(H, idx[:-1], axis=ax)          # 左邻，size N-1
        Hn = jnp.take(H, idx[1:], axis=ax)           # 右邻，size N-1
        ac = jnp.take(alpha, idx[:-1], axis=ax)
        an = jnp.take(alpha, idx[1:], axis=ax)
        face_a = 0.5 * (ac + an)
        dH = (Hn - Hc) / dx
        flux = face_a * dH                            # 面通量，size N-1
        z = jnp.zeros_like(jnp.take(flux, idx[:1], axis=ax))
        flux_r = jnp.concatenate([flux, z], axis=ax)  # 右面通量（末面=0 绝热）
        flux_l = jnp.concatenate([z, flux], axis=ax)  # 左面通量（首面=0 绝热）
        div = div + (flux_r - flux_l) / dx
    return div


# ---------------------------------------------------------------------------
# 移动高斯热源 + 分层扫描路径
# ---------------------------------------------------------------------------
def _build_scan_positions(coords, process, dx, *, margin_frac=0.06):
    """生成分层 zigzag 扫描位置，按网格分辨率连续采样（间距 ≈ dx/2），
    使每个体素在光束扫过时停留多步、足以熔化。返回形状 (n_steps, 3)。
    """
    x = coords[..., 0]; y = coords[..., 1]; z = coords[..., 2]
    x_min, x_max = jnp.min(x), jnp.max(x)
    y_min, y_max = jnp.min(y), jnp.max(y)
    z_min, z_max = jnp.min(z), jnp.max(z)
    x_ext = max(float(x_max - x_min), 1e-6)
    y_ext = max(float(y_max - y_min), 1e-6)
    z_ext = max(float(z_max - z_min), 1e-9)

    n_layers = int(jnp.clip(jnp.round(
        jnp.mean(jnp.atleast_1d(jnp.asarray(process.layer_thickness))) /
        max(z_ext, 1e-9)), 1, 8))
    hatch = float(jnp.mean(jnp.atleast_1d(jnp.asarray(process.hatch_spacing))))
    hatch = max(hatch, dx * 1.5)
    n_lines = max(1, int(jnp.clip(jnp.round(y_ext / hatch), 1, 16)))

    # 沿 x 连续采样：间距 ≈ dx/2，保证光束平滑扫过每个体素
    n_per_line = max(2, int(jnp.clip(jnp.round(x_ext / (dx * 0.5)), 2, 64)))
    xs = jnp.linspace(x_min + x_ext * margin_frac, x_max - x_ext * margin_frac, n_per_line)

    ps = []
    for l in range(n_layers):
        zs = z_min + (l + 0.5) * z_ext / n_layers
        for j in range(n_lines):
            yc = y_min + (j + 0.5) * y_ext / n_lines
            seq = xs if (j % 2 == 0) else xs[::-1]      # zigzag
            for i in range(n_per_line):
                ps.append((float(seq[i]), float(yc), float(zs)))
    return jnp.array(ps, dtype=jnp.float64)             # (total, 3)


def _moving_source(positions_t, cell_centers, Q0, r, dp):
    """单时刻体积热源 Q(x) = Q0 · exp(−ρ²/r²) · exp(−(z−zs)²/(2 dp²))。"""
    zc = cell_centers[..., 2]
    z0 = positions_t[2]
    z2 = (zc - z0) ** 2
    rho2 = jnp.sum((cell_centers - positions_t) ** 2, axis=-1) - z2
    return Q0 * jnp.exp(-rho2 / jnp.maximum(r * r, 1e-18)) * jnp.exp(-z2 / jnp.maximum(2.0 * dp * dp, 1e-18))


# ---------------------------------------------------------------------------
# 主求解器
# ---------------------------------------------------------------------------
@register_solver(
    "thermal.enthalpy",
    consumes=("PartGeometry", "ProcessPlan"),
    produces="ThermalHistory",
    stage="thermal",
    modality=("SLM", "LSF"),
    differentiable=True,
    cost=20.0,
    defaults={"material": "316L"},
    doc="enthalpy 法相变热传导：移动高斯热源 + 固液潜热（高保真热解）；"
        "用 select={'thermal':'thermal.enthalpy'} 显式启用。",
)
def solve_enthalpy_thermal(*, geometry, process, params=None):
    """enthalpy 法相变热传导：移动激光热源 + 固液潜热。

    注册名 ``thermal.enthalpy``；consumes (geometry, process)；produces
    ``ThermalHistory``。材料自 ``params['material']`` 解析（默认 316L）。
    """
    p = dict(params or {})
    mat = get_material(p.get("material", "316L"))

    rho = float(mat.rho_solid)
    cp = float(mat.cp_solid)
    k = float(mat.k_solid)
    L = float(mat.latent_fusion)                       # 潜热 [J/kg]
    T_amb = float(mat.T_ambient)
    T_sol = float(mat.T_solidus)
    T_liq = float(mat.T_liquidus)

    spacing = float(geometry.spacing)
    dx = spacing
    mask = (geometry.sdf < 0.0).astype(jnp.float64)    # 仅在实体内部加热
    coords = geometry.coords()                          # (..., dim)

    # 工艺量（保持可微：以 tracer 形式进入热源位置/功率）
    P = jnp.mean(jnp.atleast_1d(jnp.asarray(process.laser_power)))
    r = jnp.mean(jnp.atleast_1d(jnp.asarray(process.beam_radius)))
    eta = jnp.mean(jnp.atleast_1d(jnp.asarray(process.absorption)))
    _v = jnp.mean(jnp.atleast_1d(jnp.asarray(process.scan_speed)))

    # 热源强度归一化：∫Q dV ≈ η P（单位时间）
    dp = jnp.maximum(r * 1.2, dx)                      # 熔深尺度
    Q0 = eta * P / (math.pi * r * r * math.sqrt(2.0 * math.pi) * dp + 1e-18)
    # 线能量密度 ∝ P/v：扫描速度越快、单位行程沉积能量越少、峰值温度越低。
    # 以 v_ref 校准（默认速度下因子=1，保持已标定的熔化行为），并钳制避免数值失稳。
    v_ref = 0.8
    Q0 = Q0 * jnp.clip(v_ref / jnp.maximum(_v, 1e-9), 0.3, 3.0)

    # 时间步（显式扩散稳定性）
    alpha0 = k / (rho * cp + 1e-12)
    cfl = float(p.get("cfl", 0.35))
    dt = cfl * dx * dx / (2.0 * coords.ndim * alpha0 + 1e-18)
    dt = min(dt, 5e-4)

    n_steps = int(p.get("n_steps", 0)) or None
    hcool = float(p.get("h_cool", 0.5))                # 弱 Newton 冷却 [1/s]

    positions = _build_scan_positions(coords, process, dx)
    if n_steps is None:
        n_steps = int(positions.shape[0])

    H0 = jnp.zeros_like(mask)                          # 初态环境温度 → 焓 0

    def rhs(H, t):
        T = temperature_of_enthalpy(H, rho=rho, cp=cp, L=L, T_amb=T_amb,
                                    T_sol=T_sol, T_liq=T_liq)
        alpha = effective_diffusivity(T, k=k, rho=rho, cp=cp, L=L,
                                      T_sol=T_sol, T_liq=T_liq)
        lap = _div_alpha_grad(H, alpha, dx)
        Q = _moving_source(positions[t], coords, Q0, r, dp) * mask
        cool = hcool * (T - T_amb) * mask
        return lap + Q - cool

    def body(carry, t):
        H, peak, cool_rate, t_above = carry
        T = temperature_of_enthalpy(H, rho=rho, cp=cp, L=L, T_amb=T_amb,
                                    T_sol=T_sol, T_liq=T_liq)
        k1 = rhs(H, t)
        H1 = H + dt * k1
        k2 = rhs(H1, t)
        Hn = H + 0.5 * dt * (k1 + k2)                  # SSP-RK2
        Tn = temperature_of_enthalpy(Hn, rho=rho, cp=cp, L=L, T_amb=T_amb,
                                     T_sol=T_sol, T_liq=T_liq)
        peak = jnp.maximum(peak, Tn)
        cool_rate = jnp.maximum(cool_rate, jnp.maximum(T - Tn, 0.0) / dt)
        t_above = t_above + dt * (Tn > T_sol)
        return (Hn, peak, cool_rate, t_above), None

    scan_out, _ = jax.lax.scan(
        body, (H0, jnp.zeros_like(mask), jnp.zeros_like(mask), jnp.zeros_like(mask)),
        jnp.arange(n_steps),
    )
    Hf, peak_T, cool_rate, t_above = scan_out
    Tf = temperature_of_enthalpy(Hf, rho=rho, cp=cp, L=L, T_amb=T_amb,
                                 T_sol=T_sol, T_liq=T_liq)

    # 凝固前沿 G 与 R
    grads = jnp.gradient(Tf, dx)
    G = jnp.sqrt(sum(g ** 2 for g in grads))
    R = cool_rate / jnp.maximum(G, 1e-3)

    return ThermalHistory(
        peak_temperature=jnp.asarray(peak_T),
        cooling_rate=jnp.asarray(cool_rate),
        thermal_gradient=jnp.asarray(G),
        solidification_rate=jnp.asarray(R),
        time_above_melt=jnp.asarray(t_above),
        final_temperature=jnp.asarray(Tf),
        spacing=spacing,
        dim=geometry.dim,
    )
