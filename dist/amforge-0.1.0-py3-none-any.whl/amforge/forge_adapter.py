"""AM 适配层：把 amforge 的求解器注册进 ForgeCore 通用注册表。

端口用「插槽名」作标识（geometry / process / meltpool / thermal /
microstructure / constitutive / asbuilt / structural / verdict），
与 amforge 的契约类名解耦，使 ForgeCore 成为与具体物理域无关的通用引擎。

注册后，任意 SimulationModel 都能用统一接口跑 AM 全链路，且 jax.grad
可穿透整图（可微优化「免费」获得）。

设计要点：
* process 有两个生产者。让几何感知的 heuristic(0.5) 成本低于常量
  constant(1.0)，于是「给定几何时默认走 heuristic，缺几何时回退 constant」。
* 高保真求解器（meltpool.vof_flow3d / thermal.enthalpy 等）在此追加注册，
  并用 select={"thermal": "thermal.enthalpy"} 显式切换（不破坏默认轻量链路）。
"""
from __future__ import annotations

import inspect
from typing import Optional

from forgecore.registry import REGISTRY

from amforge.meltpool import solve_meltpool_surrogate
from amforge.thermal import solve_thermal_history
from amforge.thermal_enthalpy import solve_enthalpy_thermal
from amforge.micro import solve_microstructure
from amforge.constitutive import solve_constitutive
from amforge.buildup import solve_buildup
from amforge.asbuilt_plastic import solve_asbuilt_plastic
from amforge.digitaltwin import solve_digital_twin
from amforge.verdict import solve_verdict
from amforge.process import _solve_constant as solve_process_constant
from amforge.process import heuristic_plan
from amforge.inverse import solve_inverse_process

_DONE = False


# heuristic_plan 以 **params 展开接收参数，但只接受其签名内的命名参数；
# forgecore 的全局 params 可能含其它求解器的键（如 n_grid），需按签名过滤，
# 否则会 TypeError: unexpected keyword argument。
_HEUR_ALLOWED = tuple(
    n for n, p in inspect.signature(heuristic_plan).parameters.items()
    if n != "geometry"
)


def _solve_heuristic_adapter(*, geometry, params=None):
    p = dict(params or {})
    kw = {k: p[k] for k in _HEUR_ALLOWED if k in p}
    return heuristic_plan(geometry, **kw)


def register_am_solvers(force: bool = False) -> None:
    global _DONE
    if _DONE and not force:
        return
    R = REGISTRY

    # 工艺规划（两个生产者：几何感知优先）
    R.register_fn(
        "process.constant", "process", (),
        fn=solve_process_constant, cost=1.0,
        defaults={"modality": "SLM"},
        doc="params 指定的均匀工艺方案（无几何依赖）。",
    )
    R.register_fn(
        "process.heuristic", "process", ("geometry",),
        fn=_solve_heuristic_adapter, cost=0.5, modality=("SLM", "LSF"),
        defaults={"material": "Ti6Al4V", "modality": "SLM", "target_enthalpy": 12.0},
        doc="几何感知规则式工艺规划：悬垂/薄壁降功率 + 无量纲焓锁定工艺窗口。",
    )

    # 宏观点-线尺度
    R.register_fn(
        "meltpool.surrogate_eagar_tsai", "meltpool", ("geometry", "process"),
        fn=solve_meltpool_surrogate, cost=1.0, modality=("SLM", "LSF"),
        doc="Eagar-Tsai 半解析熔池代理模型。",
    )
    R.register_fn(
        "thermal.history", "thermal", ("geometry", "process", "meltpool"),
        fn=solve_thermal_history, cost=2.0, modality=("SLM", "LSF"),
        doc="由逐道熔池累积零件级热历史（峰值温/冷却率/温度梯度/凝固速率）。",
    )
    R.register_fn(
        "thermal.enthalpy", "thermal", ("geometry", "process"),
        fn=solve_enthalpy_thermal, cost=2.0, modality=("SLM", "LSF"),
        tags=("high-fidelity", "phase-change"),
        doc="enthalpy 法相变热传导（移动高斯热源 + 固液潜热），高保真热解；"
            "用 select={'thermal':'thermal.enthalpy'} 显式启用。",
    )

    # 微观 -> 本构
    R.register_fn(
        "micro.surrogate", "microstructure", ("thermal", "meltpool"),
        fn=solve_microstructure, cost=2.0, modality=("SLM", "LSF"),
        doc="冷却率幂律晶粒尺寸 + 柱状分数 + 孔隙的微观代理。",
    )
    R.register_fn(
        "constitutive.homogenize", "constitutive", ("microstructure",),
        fn=solve_constitutive, cost=1.0,
        doc="Hall-Petch 屈服 + 孔隙折减 + 各向异性的宏观本构均质化。",
    )

    # 成形 + 数字样机
    R.register_fn(
        "buildup.layer_activation", "asbuilt",
        ("geometry", "process", "thermal", "microstructure"),
        fn=solve_buildup, cost=3.0,
        doc="逐层激活：热应变/残余应力/翘曲/变形后的成形件（降级趋势模型）。",
    )
    R.register_fn(
        "asbuilt.thermomechanical_plastic", "asbuilt",
        ("geometry", "thermal"),
        fn=solve_asbuilt_plastic, cost=4.0,
        tags=("high-fidelity", "elasto-plastic", "cpfe"),
        doc="塑性/CPFE 生死单元 FEM 高保真成形（J2 各向同性硬化 或 速率相关晶体塑性）；"
            "默认链路不启用（避免 OOM），须用 select={'asbuilt':'asbuilt.thermomechanical_plastic'} "
            "显式切换。",
    )
    R.register_fn(
        "digitaltwin.rom", "structural", ("asbuilt", "constitutive"),
        fn=solve_digital_twin, cost=4.0,
        doc="降阶数字样机：代表服役应力下的位移与应力集中。",
    )
    R.register_fn(
        "verdict.service", "verdict", ("structural", "asbuilt", "constitutive"),
        fn=solve_verdict, cost=1.0,
        doc="强度/刚度/疲劳/磨损安全系数与服役判定。",
    )

    # 可微逆问题（功能 2 入口）：几何 -> 工艺
    R.register_fn(
        "inverse.predict_process", "process", ("geometry",),
        fn=solve_inverse_process, cost=0.7, differentiable=True,
        doc="神经网络从几何预测工艺（功能2 可微闭环的可插拔求解器）。",
    )

    _DONE = True


# 导入即注册（幂等）
register_am_solvers()
