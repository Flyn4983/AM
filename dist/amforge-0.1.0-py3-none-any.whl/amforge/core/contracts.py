"""AMForge 模块间数据契约 (data contracts).

本模块是整个平台"**模块之间无缝链接**"的核心。每个求解器模块都不直接依赖
其它模块的内部实现，而只依赖这里定义的一组**契约对象**：

    PartGeometry   →  ProcessPlan  →  ThermalHistory / MeltPoolResult
                                   →  MicrostructureResult
                                   →  ConstitutiveField
                                   →  AsBuiltPart
                                   →  ServiceVerdict

只要一个模块声明自己 *消费* 哪些契约、*产出* 哪些契约
(见 :mod:`amforge.core.registry`)，编排器 (:mod:`amforge.core.graph`) 就能
自动把它接到管线的正确位置上，无需手写胶水代码。

设计约束
--------
1. **全部为 frozen dataclass**，数值字段是 JAX 数组 → 注册为 pytree，
   因此 ``jax.grad`` / ``jax.jit`` / ``jax.vmap`` 可以穿过任意契约对象。
2. **静态元数据**（维度、网格尺寸、材料名、方法名等）放在 ``aux`` 里，
   不参与求导，避免 JIT 反复重编译。
3. **单位一律 SI**（m, s, K, Pa, W, kg）。契约文档字符串标注每个量的单位。
"""
from __future__ import annotations

from dataclasses import dataclass, field, fields, replace
from typing import Any, Callable, Sequence

import jax
import jax.numpy as jnp
import numpy as np

Array = jnp.ndarray


# ---------------------------------------------------------------------------
# pytree 注册辅助工具
# ---------------------------------------------------------------------------
def register_contract(cls, leaf_names: Sequence[str], aux_names: Sequence[str]):
    """把一个 frozen dataclass 注册为 JAX pytree。

    ``leaf_names`` 中的字段作为可微叶子 (JAX 数组 / 标量)；
    ``aux_names`` 中的字段作为静态元数据 (必须 hashable)。
    """
    leaf_names = tuple(leaf_names)
    aux_names = tuple(aux_names)

    def _flatten(obj):
        leaves = tuple(getattr(obj, k) for k in leaf_names)
        aux = tuple(getattr(obj, k) for k in aux_names)
        return leaves, aux

    def _unflatten(aux, leaves):
        kw = dict(zip(leaf_names, leaves))
        kw.update(dict(zip(aux_names, aux)))
        return cls(**kw)

    jax.tree_util.register_pytree_node(cls, _flatten, _unflatten)
    return cls


def _as_array(x, dtype=jnp.float64):
    return jnp.asarray(x, dtype=dtype)


# ===========================================================================
# 1. 几何契约 —— 任意复杂构型
# ===========================================================================
@dataclass(frozen=True)
class PartGeometry:
    """待制造零件的**任意复杂几何**表示（体素化带符号距离场）。

    采用 SDF (signed distance field) 体素栅格作为统一几何载体，理由：

    * STL / STEP / 隐式 CSG / 点云 都能统一转成 SDF，因此"任意复杂构型"
      不受几何来源限制；
    * SDF 天然可微 —— 几何本身可以作为优化变量（拓扑/形状优化）；
    * 分层切片、扫描路径生成、生死单元激活、几何偏差比较，
      都能在同一个栅格上完成，避免跨模块的网格映射误差。

    Attributes
    ----------
    sdf : (nx, ny, nz) 或 (nx, ny)
        带符号距离场 [m]，**负值在零件内部**。
    origin : (dim,)
        栅格原点物理坐标 [m]。
    spacing : float
        体素边长 [m]（等距栅格）。
    dim : int
        2 或 3（静态）。
    name : str
        零件名（静态）。
    """

    sdf: Array
    origin: Array
    spacing: float
    dim: int = 3
    name: str = "part"

    # ---- 派生量 ----------------------------------------------------------
    @property
    def shape(self) -> tuple[int, ...]:
        return tuple(self.sdf.shape)

    @property
    def occupancy(self) -> Array:
        """硬占位（0/1），负 SDF 即为实体。"""
        return (self.sdf < 0.0).astype(self.sdf.dtype)

    def soft_occupancy(self, eps: float | None = None) -> Array:
        """**可微**软占位：用 tanh 平滑 Heaviside，供梯度穿过几何比较。

        eps 默认取 1 个体素，保证界面上有 ~2 个体素的过渡带。
        """
        if eps is None:
            eps = float(self.spacing)
        return 0.5 * (1.0 - jnp.tanh(self.sdf / jnp.maximum(eps, 1e-12)))

    def volume(self) -> Array:
        """实体体积 [m^dim]（可微，用软占位积分）。"""
        cell = self.spacing ** self.dim
        return jnp.sum(self.soft_occupancy()) * cell

    def bbox(self) -> tuple[Array, Array]:
        """零件包围盒 (lo, hi) [m]。"""
        lo = self.origin
        hi = self.origin + self.spacing * (jnp.asarray(self.shape) - 1.0)
        return lo, hi

    def layer_count(self, layer_thickness: float) -> int:
        """给定层厚时的层数（沿最后一个轴 = 构建方向 Z）。"""
        height = self.spacing * (self.shape[-1] - 1)
        return max(1, int(np.ceil(float(height) / float(layer_thickness))))

    def coords(self) -> Array:
        """体素中心坐标 (..., dim) [m]。"""
        axes = [self.origin[d] + self.spacing * jnp.arange(self.shape[d])
                for d in range(self.dim)]
        grids = jnp.meshgrid(*axes, indexing="ij")
        return jnp.stack(grids, axis=-1)


register_contract(PartGeometry, ("sdf", "origin", "spacing"), ("dim", "name"))


# ===========================================================================
# 2. 工艺契约 —— 神经网络的预测目标 / 各求解器的输入
# ===========================================================================
@dataclass(frozen=True)
class ProcessPlan:
    """增材制造**工艺方案**：逐层工艺参数 + 扫描策略。

    这是"几何 → 工艺"神经网络的**输出**，也是所有物理求解器的**输入**。
    全部字段都是可微叶子，因此损失函数对工艺参数的梯度可以一路回传到
    预测网络的权重上。

    Attributes
    ----------
    laser_power : (n_layers,) 或 标量
        激光功率 [W]。
    scan_speed : (n_layers,) 或 标量
        扫描速度 [m/s]。
    layer_thickness : 标量
        层厚 [m]。
    hatch_spacing : 标量
        扫描间距 [m]。
    beam_radius : 标量
        光斑 1/e² 半径 [m]。
    scan_angle : (n_layers,)
        每层扫描方向角 [rad]（层间旋转策略）。
    absorption : 标量
        激光吸收率 [-]。
    preheat_temp : 标量
        基板/粉床预热温度 [K]。
    powder_feed_rate : 标量
        送粉率 [kg/s]（LSF/DED 专用，SLM 置 0）。
    dwell_time : 标量
        层间停留时间 [s]。
    modality : str
        ``"SLM"`` 或 ``"LSF"``（静态）。
    """

    laser_power: Array
    scan_speed: Array
    layer_thickness: Array
    hatch_spacing: Array
    beam_radius: Array
    scan_angle: Array
    absorption: Array
    preheat_temp: Array
    powder_feed_rate: Array
    dwell_time: Array
    modality: str = "SLM"

    # ---- 工艺派生指标 ----------------------------------------------------
    def volumetric_energy_density(self) -> Array:
        """体能量密度 VED = P / (v · h · t) [J/mm³ → 这里给 J/m³]。

        文献中最常用的工艺综合指标（可行性报告 4.1 节）。
        """
        denom = (self.scan_speed * self.hatch_spacing * self.layer_thickness)
        return self.laser_power / jnp.maximum(denom, 1e-30)

    def linear_energy_density(self) -> Array:
        """线能量密度 P/v [J/m]，控制熔池尺度的一阶指标。"""
        return self.laser_power / jnp.maximum(self.scan_speed, 1e-30)

    def normalized_enthalpy(self, *, rho: float, cp: float, T_melt: float,
                            diffusivity: float) -> Array:
        """无量纲焓 ΔH/h_s —— keyhole 转变的经典判据。

        ΔH/h_s = A·P / (ρ·cp·T_m · sqrt(π·α·v·r³))
        经验阈值：> ~30 进入 keyhole 模式（易产生匙孔气孔）。
        """
        hs = rho * cp * T_melt
        denom = jnp.sqrt(jnp.pi * diffusivity * self.scan_speed
                         * self.beam_radius ** 3)
        return self.absorption * self.laser_power / jnp.maximum(hs * denom, 1e-30)

    @property
    def n_layers(self) -> int:
        return int(jnp.atleast_1d(self.scan_angle).shape[0])

    def as_vector(self) -> Array:
        """把工艺方案摊平成一维向量（供优化器/网络使用）。"""
        return jnp.concatenate([jnp.atleast_1d(jnp.asarray(v)).ravel()
                                for v in (self.laser_power, self.scan_speed,
                                          self.layer_thickness, self.hatch_spacing,
                                          self.beam_radius, self.scan_angle,
                                          self.absorption, self.preheat_temp,
                                          self.powder_feed_rate, self.dwell_time)])

    def replace(self, **kw) -> "ProcessPlan":
        return replace(self, **kw)

    @staticmethod
    def uniform(n_layers: int = 1, *, modality: str = "SLM",
                laser_power: float = 200.0, scan_speed: float = 1.0,
                layer_thickness: float = 40e-6, hatch_spacing: float = 80e-6,
                beam_radius: float = 50e-6, absorption: float = 0.4,
                preheat_temp: float = 373.0, powder_feed_rate: float = 0.0,
                dwell_time: float = 0.0,
                rotation_per_layer: float = 67.0 * np.pi / 180.0) -> "ProcessPlan":
        """构造一个均匀工艺方案（默认 67° 层间旋转，工业界常用策略）。"""
        ang = rotation_per_layer * jnp.arange(n_layers, dtype=jnp.float64)
        return ProcessPlan(
            laser_power=_as_array(laser_power),
            scan_speed=_as_array(scan_speed),
            layer_thickness=_as_array(layer_thickness),
            hatch_spacing=_as_array(hatch_spacing),
            beam_radius=_as_array(beam_radius),
            scan_angle=ang,
            absorption=_as_array(absorption),
            preheat_temp=_as_array(preheat_temp),
            powder_feed_rate=_as_array(powder_feed_rate),
            dwell_time=_as_array(dwell_time),
            modality=modality,
        )


register_contract(
    ProcessPlan,
    ("laser_power", "scan_speed", "layer_thickness", "hatch_spacing",
     "beam_radius", "scan_angle", "absorption", "preheat_temp",
     "powder_feed_rate", "dwell_time"),
    ("modality",),
)


# ===========================================================================
# 2.5 粉末床契约（P2 粉末尺度）—— 熔池/热解之前的"铺粉态"
# ===========================================================================
@dataclass(frozen=True)
class PowderBedResult:
    """**粉末床铺粉态 + 粉末尺度缺陷前驱**（DEM/SPH/MPM 颗粒尺度求解产物）。

    连续介质熔池模型（:class:`MeltPoolResult`）以"均质连续金属"为出发点，
    因此**看不到粉末颗粒本身**引起的三类缺陷：

    * **球化 (balling)**：熔道在 Plateau–Rayleigh 不稳定性下断裂成球串；
    * **未熔合 (lack of fusion)**：铺粉密度不足 / 粉层过厚 → 层间未连接；
    * **飞溅 (spatter) + 剥蚀 (denudation)**：蒸气反冲 / 气流卷吸抛出颗粒。

    这三者都是**颗粒尺度**现象，只能由 DEM（铺粉重排）、SPH（熔道自由界面）、
    MPM（粉末再分布）给出。本契约把它们汇总成可微指标，供逆问题的 defect
    罚项使用 —— 即"粉末尺度缺陷"进入工艺优化目标的通路。

    Attributes
    ----------
    packing_density : 标量
        铺粉体积分数 ∈ [0,1]（典型 SLM 粉床 0.50~0.62；越低越易未熔合）。
    coordination_number : 标量
        平均配位数 [-]（颗粒平均接触数，密实床 ~6~8）。
    surface_roughness : 标量
        铺粉/熔道表面粗糙度 Ra [m]（下一层铺粉的初始不平度）。
    balling_indicator : 标量
        球化风险 ∈ [0,1]（Plateau–Rayleigh 判据 L/W > π）。
    lof_indicator : 标量
        未熔合风险 ∈ [0,1]（铺粉密度 + 层厚/熔深 + 搭接率）。
    spatter_fraction : 标量
        飞溅质量分数 ∈ [0,1]（被抛出粉床的质量 / 总质量）。
    denudation_width : 标量
        剥蚀区半宽 [m]（熔道两侧被气流卷走粉末的宽度）。
    porosity : 标量
        粉末尺度孔隙率 ∈ [0,1]（未熔合孔 + 夹带气孔）。
    dim : int
        维度（静态）。
    method : str
        产生本结果的颗粒方法（``"surrogate"`` / ``"dem"`` / ``"sph"`` /
        ``"mpm"``，静态，仅供追溯）。
    """

    packing_density: Array
    coordination_number: Array
    surface_roughness: Array
    balling_indicator: Array
    lof_indicator: Array
    spatter_fraction: Array
    denudation_width: Array
    porosity: Array
    dim: int = 3
    method: str = "surrogate"

    def defect_score(self) -> Array:
        """粉末尺度综合缺陷评分 ∈ [0,1]，越大越差。

        权重取向与 :meth:`MeltPoolResult.defect_score` 一致（未熔合权重最高，
        因为它对疲劳寿命最致命），但物理来源完全不同：这里来自颗粒尺度。
        """
        return jnp.clip(
            0.45 * self.lof_indicator
            + 0.35 * self.balling_indicator
            + 0.20 * self.spatter_fraction, 0.0, 1.0)

    def recoat_quality(self) -> Array:
        """铺粉质量 ∈ [0,1]，越大越好（密实且平整）。

        以典型可铺粉下限 0.45 为零点、理想随机密堆 0.64 为满分线性映射，
        再按粗糙度相对粉层尺度折减。
        """
        dens = jnp.clip((self.packing_density - 0.45) / (0.64 - 0.45), 0.0, 1.0)
        rough = 1.0 / (1.0 + self.surface_roughness / 3e-5)
        return dens * rough


register_contract(
    PowderBedResult,
    ("packing_density", "coordination_number", "surface_roughness",
     "balling_indicator", "lof_indicator", "spatter_fraction",
     "denudation_width", "porosity"),
    ("dim", "method"),
)


# ===========================================================================
# 3. 热历史契约
# ===========================================================================
@dataclass(frozen=True)
class ThermalHistory:
    """热历史 —— 连接"工艺"与"微观组织/残余应力"的枢纽契约。

    Attributes
    ----------
    peak_temperature : (...,) 栅格
        每点经历的峰值温度 [K]。
    cooling_rate : (...,)
        凝固区间平均冷却速率 [K/s]（正值）。
    thermal_gradient : (...,)
        凝固前沿温度梯度 G [K/m]。
    solidification_rate : (...,)
        凝固前沿推进速率 R [m/s]。
    time_above_melt : (...,)
        高于熔点的累计时间 [s]（重熔次数的代理量）。
    final_temperature : (...,)
        模拟结束时刻温度场 [K]。
    spacing : float
        栅格体素尺寸 [m]。
    dim : int
        维度（静态）。
    """

    peak_temperature: Array
    cooling_rate: Array
    thermal_gradient: Array
    solidification_rate: Array
    time_above_melt: Array
    final_temperature: Array
    spacing: float = 1e-5
    dim: int = 3

    def gr_ratio(self) -> Array:
        """G/R —— 凝固形貌判据（大 → 柱状晶，小 → 等轴晶）。"""
        return self.thermal_gradient / jnp.maximum(self.solidification_rate, 1e-12)

    def cooling_rate_gr(self) -> Array:
        """G·R = 冷却速率 [K/s]，控制枝晶臂间距与晶粒细化程度。"""
        return self.thermal_gradient * self.solidification_rate


register_contract(
    ThermalHistory,
    ("peak_temperature", "cooling_rate", "thermal_gradient",
     "solidification_rate", "time_above_melt", "final_temperature"),
    ("spacing", "dim"),
)


# ===========================================================================
# 4. 熔池契约
# ===========================================================================
@dataclass(frozen=True)
class MeltPoolResult:
    """熔池多物理场求解结果（Flow3D 式自由界面 CFD 的输出）。

    Attributes
    ----------
    vof : (...,)
        金属体积分数 F ∈ [0,1]（VOF 自由界面）。
    temperature : (...,)
        温度场 [K]。
    liquid_fraction : (...,)
        液相分数 f_l ∈ [0,1]。
    velocity : (..., dim)
        流场速度 [m/s]。
    pressure : (...,)
        压力 [Pa]。
    depth / width / length : 标量
        熔池深度 / 宽度 / 长度 [m]。
    keyhole_depth : 标量
        匙孔深度 [m]（蒸发反冲压凹陷）。
    lof_indicator : 标量
        未熔合 (lack-of-fusion) 风险指标 ∈ [0,1]。
    porosity_indicator : 标量
        匙孔气孔风险指标 ∈ [0,1]。
    spatter_indicator : 标量
        飞溅风险指标 ∈ [0,1]。
    """

    vof: Array
    temperature: Array
    liquid_fraction: Array
    velocity: Array
    pressure: Array
    depth: Array
    width: Array
    length: Array
    keyhole_depth: Array
    lof_indicator: Array
    porosity_indicator: Array
    spatter_indicator: Array
    spacing: float = 5e-6
    dim: int = 3

    def aspect_ratio(self) -> Array:
        """熔池深宽比 —— 传导模式 (<0.5) vs 匙孔模式 (>~1) 的判别量。"""
        return self.depth / jnp.maximum(self.width, 1e-12)

    def defect_score(self) -> Array:
        """综合缺陷评分 ∈ [0,1]，越大越差（用于工艺窗口筛选）。"""
        return jnp.clip(
            0.45 * self.lof_indicator
            + 0.40 * self.porosity_indicator
            + 0.15 * self.spatter_indicator, 0.0, 1.0)


register_contract(
    MeltPoolResult,
    ("vof", "temperature", "liquid_fraction", "velocity", "pressure",
     "depth", "width", "length", "keyhole_depth",
     "lof_indicator", "porosity_indicator", "spatter_indicator"),
    ("spacing", "dim"),
)


# ===========================================================================
# 5. 微观组织契约
# ===========================================================================
@dataclass(frozen=True)
class MicrostructureResult:
    """微观组织（相场 / CA 求解结果 + 统计特征）。

    Attributes
    ----------
    phi : (...,)
        固相序参量 ∈ [0,1]。
    orientation : (...,)
        晶粒取向角 [rad]。
    grain_size : (...,)
        局部晶粒尺寸场 [m]。
    columnar_fraction : (...,)
        柱状晶体积分数 ∈ [0,1]（其余为等轴晶）。
    texture_intensity : (...,)
        织构强度 ∈ [0,1]（0=随机取向，1=单晶）。
    porosity : (...,)
        孔隙率 ∈ [0,1]。
    mean_grain_size : 标量
        体积平均晶粒尺寸 [m]。
    """

    phi: Array
    orientation: Array
    grain_size: Array
    columnar_fraction: Array
    texture_intensity: Array
    porosity: Array
    mean_grain_size: Array
    spacing: float = 1e-6
    dim: int = 3

    def hall_petch_strength(self, sigma_0: float, k_hp: float) -> Array:
        """Hall-Petch 关系：σ_y = σ_0 + k / sqrt(d)  [Pa]。"""
        d = jnp.maximum(self.grain_size, 1e-9)
        return sigma_0 + k_hp / jnp.sqrt(d)


register_contract(
    MicrostructureResult,
    ("phi", "orientation", "grain_size", "columnar_fraction",
     "texture_intensity", "porosity", "mean_grain_size"),
    ("spacing", "dim"),
)


# ===========================================================================
# 6. 本构契约 —— 微观模拟的最终产物、宏观仿真的输入
# ===========================================================================
@dataclass(frozen=True)
class ConstitutiveField:
    """**空间分辨的各向异性弹塑性本构参数场**。

    这是可行性报告点明的"关键断点"（微观组织 → 零件级本构）的产物形态：
    不是一组标量材料常数，而是**逐点的本构参数场**，因此能表达增材件
    固有的各向异性与空间不均匀性。

    弹性：横观各向同性（构建方向 Z 为对称轴），由 (E_x, E_z, nu, G_xz) 描述。
    塑性：Hill48 各向异性屈服 + Voce 硬化。

    Attributes
    ----------
    E_inplane, E_build : (...,)
        面内 / 构建方向弹性模量 [Pa]。
    nu : (...,)
        泊松比 [-]。
    G_build : (...,)
        面外剪切模量 [Pa]。
    sigma_y0 : (...,)
        初始屈服强度 [Pa]。
    hardening_sat : (...,)
        Voce 饱和硬化增量 [Pa]。
    hardening_rate : (...,)
        Voce 硬化速率 [-]。
    hill_F, hill_G, hill_H, hill_L, hill_M, hill_N : (...,)
        Hill48 各向异性系数 [-]。
    porosity : (...,)
        孔隙率 [-]（用于刚度/强度折减）。
    damage : (...,)
        初始损伤 ∈ [0,1]。
    """

    E_inplane: Array
    E_build: Array
    nu: Array
    G_build: Array
    sigma_y0: Array
    hardening_sat: Array
    hardening_rate: Array
    hill_F: Array
    hill_G: Array
    hill_H: Array
    hill_L: Array
    hill_M: Array
    hill_N: Array
    porosity: Array
    damage: Array
    spacing: float = 1e-4
    dim: int = 3

    # ---- 派生 ------------------------------------------------------------
    def effective_stiffness(self) -> Array:
        """孔隙+损伤折减后的等效模量（Mori-Tanaka 型简化）[Pa]。"""
        red = (1.0 - self.porosity) ** 2 * (1.0 - self.damage)
        return jnp.cbrt(self.E_inplane ** 2 * self.E_build) * red

    def anisotropy_ratio(self) -> Array:
        """各向异性度 E_z / E_x（增材件典型 0.85~1.0）。"""
        return self.E_build / jnp.maximum(self.E_inplane, 1e-9)

    def homogenized(self) -> dict[str, float]:
        """体积平均后的标量本构（供快速宏观仿真/报表）。"""
        m = lambda a: float(jnp.mean(a))  # noqa: E731
        return {
            "E_inplane": m(self.E_inplane), "E_build": m(self.E_build),
            "nu": m(self.nu), "G_build": m(self.G_build),
            "sigma_y0": m(self.sigma_y0),
            "hardening_sat": m(self.hardening_sat),
            "hardening_rate": m(self.hardening_rate),
            "porosity": m(self.porosity),
            "anisotropy_ratio": m(self.anisotropy_ratio()),
        }


register_contract(
    ConstitutiveField,
    ("E_inplane", "E_build", "nu", "G_build", "sigma_y0",
     "hardening_sat", "hardening_rate",
     "hill_F", "hill_G", "hill_H", "hill_L", "hill_M", "hill_N",
     "porosity", "damage"),
    ("spacing", "dim"),
)


# ===========================================================================
# 7. As-built 构型契约 —— "模拟后的构型"，用于与理想构型比较
# ===========================================================================
@dataclass(frozen=True)
class AsBuiltPart:
    """**制造后实际构型** + 残余应力/应变状态。

    这是可微闭环 (功能2) 中与"理想构型"作比较的对象：
    几何尺寸差异 + 残余应力 + 残余应变共同构成损失函数。

    Attributes
    ----------
    sdf : (...,)
        变形后（含热收缩/翘曲）的带符号距离场 [m]。
    displacement : (..., dim)
        相对名义几何的位移场 [m]。
    residual_stress : (..., n_comp)
        残余应力张量分量 [Pa]（Voigt: 3D=6, 2D=3）。
    residual_strain : (..., n_comp)
        残余塑性/热应变分量 [-]。
    """

    sdf: Array
    displacement: Array
    residual_stress: Array
    residual_strain: Array
    spacing: float = 1e-4
    dim: int = 3

    def soft_occupancy(self, eps: float | None = None) -> Array:
        if eps is None:
            eps = float(self.spacing)
        return 0.5 * (1.0 - jnp.tanh(self.sdf / jnp.maximum(eps, 1e-12)))

    def von_mises_residual(self) -> Array:
        """残余应力的 von Mises 等效值 [Pa]。

        注意：当输入残余应力为 0（零件外 / 平衡处）时，sqrt 的参数为 0，
        其逆向导数 ``1/(2√x)`` 会炸成 Inf/NaN，进而污染整条可微链。
        因此给参数加非负下界 + 极小护垫，使梯度在零点处有限。
        """
        s = self.residual_stress
        if self.dim == 3:
            sxx, syy, szz, sxy, syz, szx = [s[..., i] for i in range(6)]
            arg = (0.5 * ((sxx - syy) ** 2 + (syy - szz) ** 2
                         + (szz - sxx) ** 2)
                   + 3.0 * (sxy ** 2 + syz ** 2 + szx ** 2))
            return jnp.sqrt(jnp.maximum(arg, 0.0) + 1e-30)
        sxx, syy, sxy = s[..., 0], s[..., 1], s[..., 2]
        arg = sxx ** 2 - sxx * syy + syy ** 2 + 3.0 * sxy ** 2
        return jnp.sqrt(jnp.maximum(arg, 0.0) + 1e-30)

    def max_distortion(self) -> Array:
        """最大变形量 [m]。"""
        return jnp.max(jnp.linalg.norm(self.displacement, axis=-1))


register_contract(
    AsBuiltPart,
    ("sdf", "displacement", "residual_stress", "residual_strain"),
    ("spacing", "dim"),
)


# ===========================================================================
# 7.5 装配体契约（P2-③：多体 + FEM 耦合）—— digitaltwin/verdict 的新输入
# ===========================================================================
@dataclass(frozen=True)
class AssemblyResult:
    """**装配体（多体动力学 + FEM 耦合）求解结果**，P2-③ 高保真路径产物。

    把增材件与其支撑/基座建模为铰接链；**FEM 子模型（AsBuiltPart 变形场）提供
    关节柔度**，MBD 提供广义质量与载荷，二者在子模型边界处耦合
    （界面位移 ↔ 关节载荷）。本契约是数字样机 / 服役判定的新输入。

    Attributes
    ----------
    joint_load : (n_joints,) 关节反力 / 力矩 [N] 或 [N·m]
    relative_displacement : (n_joints,) 关节相对位移 / 转角 [m] 或 [rad]
    flexural_stiffness : (n_joints,) FEM 子模型提供的关节弯曲刚度 [N·m/rad]
    stability_margin : 标量 线性化稳定裕度（>0 稳定；趋近 0 = 临界失稳）
    porosity : 标量 从熔池 / 本构继承的孔隙风险指标 ∈ [0,1]
    dim : int
    """

    joint_load: Array
    relative_displacement: Array
    flexural_stiffness: Array
    stability_margin: Array
    porosity: Array
    dim: int = 3

    def assembly_score(self) -> Array:
        """装配质量综合评分 ∈ [0,1]，越大越可靠（稳定且低孔隙）。"""
        return jnp.clip(self.stability_margin, 0.0, 1.0) * (1.0 - self.porosity)


register_contract(
    AssemblyResult,
    ("joint_load", "relative_displacement", "flexural_stiffness",
     "stability_margin", "porosity"),
    ("dim",),
)


# ===========================================================================
# 8. 结构响应 & 服役判定契约
# ===========================================================================
@dataclass(frozen=True)
class StructuralResult:
    """数字样机中增材件的结构响应。"""

    displacement: Array
    stress: Array           # (n_cells, n_comp) Voigt [Pa]
    strain: Array
    von_mises: Array        # (n_cells,) [Pa]
    reaction: Array         # 约束反力 [N]
    dim: int = 3

    def peak_stress(self) -> Array:
        return jnp.max(self.von_mises)


register_contract(
    StructuralResult,
    ("displacement", "stress", "strain", "von_mises", "reaction"),
    ("dim",),
)


@dataclass(frozen=True)
class ServiceVerdict:
    """数字化试验的**最终判定**：增材件在服役工况下是否合格。"""

    strength_safety_factor: Array     # 强度安全系数 σ_y / σ_max
    stiffness_ratio: Array            # 变形/许用变形
    fatigue_life_cycles: Array        # 估算疲劳寿命 [循环]
    wear_depth: Array                 # 预测磨损深度 [m]
    critical_location: Array          # 最危险点坐标 [m]
    passed: Array                     # 0/1 是否通过（可微软判定）
    margin_report: dict[str, float] = field(default_factory=dict)

    def summary(self) -> str:
        lines = [
            "═" * 62,
            "  增材制造件数字化试验判定报告",
            "═" * 62,
            f"  强度安全系数      : {float(self.strength_safety_factor):8.3f}",
            f"  刚度利用率        : {float(self.stiffness_ratio):8.3f}  (<1 合格)",
            f"  估算疲劳寿命      : {float(self.fatigue_life_cycles):8.3e} 循环",
            f"  预测磨损深度      : {float(self.wear_depth) * 1e6:8.3f} µm",
            f"  最危险点坐标      : "
            f"{np.array2string(np.asarray(self.critical_location), precision=4)}",
            "─" * 62,
            f"  判定结果          : "
            f"{'✅ 合格 (PASS)' if float(self.passed) > 0.5 else '❌ 不合格 (FAIL)'}",
            "═" * 62,
        ]
        for k, v in self.margin_report.items():
            lines.append(f"  · {k:26s}: {v:12.4g}")
        return "\n".join(lines)


# ServiceVerdict 不能走通用的 register_contract：它带一个 dict 字段
# margin_report（非张量叶子），必须自定义 flatten 把 dict 塞进 aux_data。
# 注意 aux_data 需可哈希，故转成排序后的 tuple。
jax.tree_util.register_pytree_node(
    ServiceVerdict,
    lambda o: (
        (o.strength_safety_factor, o.stiffness_ratio,
         o.fatigue_life_cycles, o.wear_depth,
         o.critical_location, o.passed,
         *tuple(o.margin_report.values())),
        (tuple(o.margin_report.keys()),),
    ),
    lambda aux, leaves: ServiceVerdict(
        *leaves[:6],
        margin_report=dict(zip(aux[0], leaves[6:]))),
)


# ===========================================================================
# 契约注册表 —— 供 registry / graph 做类型解析
# ===========================================================================
#: **以契约类名为键**。registry / graph 的类型解析全部走这张表，
#: 因为求解器声明 ``consumes=("PartGeometry", ...)`` 用的是类名。
CONTRACTS: dict[str, type] = {
    cls.__name__: cls
    for cls in (PartGeometry, ProcessPlan, PowderBedResult, ThermalHistory,
                MeltPoolResult, MicrostructureResult, ConstitutiveField,
                AsBuiltPart, AssemblyResult, StructuralResult, ServiceVerdict)
}

#: 以规范槽名为键的同一张表（便于按流水线上下文的 key 反查类型）。
CONTRACT_BY_SLOT: dict[str, type] = {
    "geometry": PartGeometry,
    "process": ProcessPlan,
    "powderbed": PowderBedResult,
    "thermal": ThermalHistory,
    "meltpool": MeltPoolResult,
    "microstructure": MicrostructureResult,
    "constitutive": ConstitutiveField,
    "asbuilt": AsBuiltPart,
    "assembly": AssemblyResult,
    "structural": StructuralResult,
    "verdict": ServiceVerdict,
}


__all__ = [
    "PartGeometry", "ProcessPlan", "PowderBedResult", "ThermalHistory",
    "MeltPoolResult", "MicrostructureResult", "ConstitutiveField",
    "AsBuiltPart", "AssemblyResult", "StructuralResult", "ServiceVerdict",
    "CONTRACTS", "CONTRACT_BY_SLOT", "register_contract",
]
